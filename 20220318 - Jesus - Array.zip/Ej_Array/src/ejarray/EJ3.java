package ejarray;

public class EJ3 {

	public static void main(String[] args) {
		

	}

}
